﻿using System;
using System.Collections.Generic;

namespace AssignmentLibrary
{
 interface ILoanable
 {
  int LoanPeriod { get; }
  string Borrower { get; set; }
  void Borrow(string borrower);
  void Return();
 }

 interface IPrintable
 {
  void Print();
 }

 class Book : ILoanable, IPrintable
 {
  public string Author { get; set; }
  public string Title { get; set; }
  public string ISBN { get; set; }
  public int LoanPeriod { get { return 21; } }
  public string Borrower { get; set; }

  public void Borrow(string borrower)
  {
   if (Borrower == null)
   {
    Borrower = borrower;
    Console.WriteLine($"{Title} by {Author} has been borrowed by {Borrower}");
   }
   else
   {
    Console.WriteLine($"{Title} by {Author} is already borrowed by {Borrower}");
   }
  }

  public void Return()
  {
   if (Borrower != null)
   {
    Console.WriteLine($"{Title} by {Author} has been returned");
    Borrower = null;
   }
   else
   {
    Console.WriteLine($"{Title} by {Author} is not borrowed");
   }
  }

  public void Print()
  {
   Console.WriteLine($"Book: {Title} by {Author} (ISBN: {ISBN})");
  }
 }

 class DVD : ILoanable, IPrintable
 {
  public string Director { get; set; }
  public string Title { get; set; }
  public int LengthInMinutes { get; set; }
  public int LoanPeriod { get { return 7; } }
  public string Borrower { get; set; }

  public void Borrow(string borrower)
  {
   if (Borrower == null)
   {
    Borrower = borrower;
    Console.WriteLine($"{Title} directed by {Director} has been borrowed by {Borrower}");
   }
   else
   {
    Console.WriteLine($"{Title} directed by {Director} is already borrowed by {Borrower}");
   }
  }

  public void Return()
  {
   if (Borrower != null)
   {
    Console.WriteLine($"{Title} directed by {Director} has been returned");
    Borrower = null;
   }
   else
   {
    Console.WriteLine($"{Title} directed by {Director} is not borrowed");
   }
  }

  public void Print()
  {
   Console.WriteLine($"DVD: {Title} directed by {Director} ({LengthInMinutes} min)");
  }
 }

 class CD : ILoanable, IPrintable
 {
  public string Artist { get; set; }
  public string Album { get; set; }
  public int LoanPeriod { get { return 14; } }
  public string Borrower { get; set; }

  public void Borrow(string borrower)
  {
   Borrower = borrower;
   Console.WriteLine($"CD {Album} by {Artist} has been borrowed by {borrower}.");
  }

  public void Return()
  {
   Console.WriteLine($"CD {Album} by {Artist} has been returned.");
   Borrower = null;
  }

  public void Print()
  {
   Console.WriteLine($"CD: {Album} by {Artist} ({(Borrower == null ? "available" : "borrowed by " + Borrower)})");
  }
 }


 class Library
 {
  private List<ILoanable> loanableItems;

  public Library()
  {
   loanableItems = new List<ILoanable>();
  }

  public void AddItem(ILoanable item)
  {
   loanableItems.Add(item);
  }

  public void RemoveItem(ILoanable item)
  {
   loanableItems.Remove(item);
  }

  public void PrintInventory()
  {
   Console.WriteLine("\nLibrary inventory:");
   foreach (IPrintable item in loanableItems)
   {
    item.Print();
   }
  }

  public void BorrowItem(ILoanable item, string borrower)
  {
   item.Borrow(borrower);
  }

  public void ReturnItem(ILoanable item)
  {
   item.Return();
  }
 }


 class Program
 {
  static void Main(string[] args)
  {
   // Create a library object
   Library library = new Library();

   // Create some book objects
   Book book1 = new Book
   {
    Author = "J.K. Rowling",
    Title = "Harry Potter and the Philosopher's Stone",
    ISBN = "9780747532743"
   };

   Book book2 = new Book
   {
    Author = "George R.R. Martin",
    Title = "A Game of Thrones",
    ISBN = "9780553573404"
   };

   // Add the books to the library
   library.AddItem(book1);
   library.AddItem(book2);

   // Print the inventory of the library
   library.PrintInventory();

   // Borrow a book
   library.BorrowItem(book1, "John Smith");

   // Print the inventory again
   library.PrintInventory();

   // Return a book
   library.ReturnItem(book1);

   // Print the inventory again
   library.PrintInventory();

   // Remove a book from the library
   library.RemoveItem(book2);

   // Print the inventory again
   library.PrintInventory();

   Console.ReadKey();
  }
 }
}

